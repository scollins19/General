#!/usr/bin/env bash


## load variables
## If configure file is not present then exit
## Configure file needs to be in same working directory as pipeline
if [[ ! -f ./chipseq_pipeline_config.sh ]]; then
 usage
 echo "Error: configuration file (chipseq_pipeline_config.sh) missing!"
 exit 1
fi 

# Load configure file
source ./chipseq_pipeline_config.sh

## If software path is not present, print error 

errprog=""
if [[ ! -x $FASTQC ]]; then
    errprog="fastqc"
fi
if [[ ! -x $BOWTIE2 ]]; then
    errprog="bowtie2"
fi
if [[ ! -x $SAMTOOLS ]]; then
    errprog="samtools"
fi

if [[ ! -x $MACS2 ]]; then
    errprog="macs2"
fi

if [[ "$errprog" ]]; then
  echo "ERROR: $errprog program not found, please edit the configure file"
  exit 1
fi


## Create logfile where output run of script will be saved 
LOGFILE=./run.log

## Begin Pipeline

{
## Start FastQC Process

echo "START: FASTQC" 

## Takes both sample and control to be processed
## Takes files ending in ".fastq"
## BASEDIR defined in configure file 
## FASTQC defined in configure file 

for F in $BASEDIR/*.fastq
do
   echo "Processing ${F##/*/}"
   $FASTQC $F
done

     
## Start Alignment Process

echo "START: BOWTIE2"

## Build genome index 
## Output file name takes same name as genome ID, but removes ".fa" 
## BOWTIE2 defined in configure file

echo "Build Index from ${GENOMEIDX}"

$BOWTIE2-build $GENOMEIDX ${GENOMEIDX%.*} 

## Begin Alignment for Sample & Control

## Takes files ending in ".fastq"
## Uses genome defined in configure file
## Output made takes same name as input file but with extension removed and ".sam" added

for F in $BASEDIR/*.fastq
do
   echo "Processing ${F##/*/}"
   $BOWTIE2 \
   -x ${GENOMEIDX%.*} \
   -U $F \
   -S ${F%.*}.sam
done 


## Alignment Post Processing with Samtools

## Convert SAM to BAM files 
## SAMTOOLS defined in configure file 
## Output made takes same name as input file but with extension removed and ".bam" added
## Intermediate files removed
## Takes output from previous step 

echo "Converting SAM to BAM"
for S in $BASEDIR/*.sam
do 
   echo "Processing ${S##/*/}"
   $SAMTOOLS view -Sb $S > ${S%.*}.bam
   echo "Removing intermediate SAM file..."
   rm $S
done 

## Remove Duplicates
## Output made takes same name as input file but with extension removed	and "rmdup.bam" added
## Takes output from previous step

echo "Removing Duplicates..."
for B in $BASEDIR/*.bam 
do 
   echo "Processing ${B##/*/}"
   $SAMTOOLS rmdup $B ${B%.*}.rmdup.bam
done

## Sorting 

## Output made takes same name as input file but with extension removed and ".sorted" added
## Removes intermediate files 
## Takes output from previous step

echo "Sorting by Chr number..."

for R in $BASEDIR/*.rmdup.bam
do
   echo "Processing: ${R##/*/}"
   $SAMTOOLS sort $R ${R%%.*}.sorted
   echo "Removing intermedite rmdup.bam file..." 
   rm $R
done


## Create BAI index 
## Takes output from previous step 

echo "Creating BAI index..." 
for S in $BASEDIR/*.sorted.bam
do 
   echo "Processing: ${S##/*/}"
   $SAMTOOLS index $S
done 

## Mapping Stats
## Takes output from previous step
## Output name is name of input with all (3) extensions removed 
## Removes intermediate file 

echo "Creating Mapping Stats..." 
for S in $BASEDIR/*.sorted.bam
do 
   echo "Processing: ${S##/*/}"
   $SAMTOOLS flagstat $S > ${S%%%.*}_mappings.txt
   echo "Removing intermediate sorted.bam files..."
   rm $S
done

## Peak Calling 
## Assuming the sample names have been kept as file names in each step, 
## the input file is the bam file which has the same name as the initial sample file
## The same applies to the control sample 

echo "START: MACS2"
echo "Calling Peaks..."

$MACS2 callpeak -t ${FASTQFILE%.*}.bam \
-c ${CONTROL%.*}.bam \
-f BAM \
-g hs \
-n macs_out \
--call-summits -B

echo "Pipeline Complete" 

} 2>&1 | tee $LOGFILE

## The output produced from the run is saved to the logfile
