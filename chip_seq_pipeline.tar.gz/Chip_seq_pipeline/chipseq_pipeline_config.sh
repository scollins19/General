#!/usr/bin/env bash

#### Load Modules ####
module load fastqc
module load bowtie
module load samtools

## FastQC needs newer version of perl 

module unload perl/5.16.2 
module load perl/5.20.1

#### Program paths ####

#if these programs are not in any PATH directories, please edit 
accordingly:
FASTQC=$(which fastqc)
BOWTIE2=$(which bowtie2)
SAMTOOLS=$(which samtools)
MACS2=$(which macs2)


## Define directory with data 

BASEDIR="/data4/scollins/chip_seq/MA5112_assign1"

## Sample file: 
FASTQFILE="$BASEDIR/chip.fastq"

## Control file:
CONTROL="$BASEDIR/input.fastq"

## Ref genome fasta file:
GENOMEIDX="$BASEDIR/chr21.fa"

## All going well, the user will be able to just change the 
## data paths in this file to use the chipseq_pipe.sh script 

